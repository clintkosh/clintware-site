$script:ArchiveExtensions = '.7z','.zip','.rar','.tar','.gz','.tgz','.bz2','.tbz','.tbz2','.xz','.txz','.cab','.iso'

function Test-ClintwareExtractSameNameEnabled {
    foreach ($ext in $script:ArchiveExtensions) {
        if (Test-Path "HKCU:\Software\Classes\SystemFileAssociations\$ext\shell\Clintware_01_7ZipExtract") { return $true }
    }
    return $false
}

function Set-ClintwareExtractSameName([bool]$Enabled) {
    $seven = Get-ClintwareSevenZip
    if ($Enabled -and -not $seven) { throw '7-Zip is not installed in a standard Program Files location.' }
    $helper = Join-Path $script:InstallRoot 'Helpers\ExtractSameName.ps1'
    foreach ($ext in $script:ArchiveExtensions) {
        $key = "HKCU:\Software\Classes\SystemFileAssociations\$ext\shell\Clintware_01_7ZipExtract"
        if ($Enabled) {
            New-Item -Path "$key\command" -Force | Out-Null
            Set-ItemProperty $key '(default)' 'Clintware™ | 7-Zip Extract to Same-Name Folder'
            Set-ItemProperty $key 'Icon' "`"$seven`""
            Set-ItemProperty $key 'Position' 'Top'
            $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$helper`" `"%1`""
            Set-ItemProperty "$key\command" '(default)' $cmd
        } else {
            Remove-Item $key -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
