function Test-ClintwareAdminHereEnabled {
    Test-Path 'HKCU:\Software\Classes\Directory\shell\Clintware_02_AdminPowerShell'
}

function Set-ClintwareAdminHere([bool]$Enabled) {
    $helper = Join-Path $script:InstallRoot 'Helpers\OpenAdminHere.ps1'
    $targets = @(
        @{ Key='HKCU:\Software\Classes\*\shell\Clintware_02_AdminPowerShell'; Arg='%1' },
        @{ Key='HKCU:\Software\Classes\Directory\shell\Clintware_02_AdminPowerShell'; Arg='%1' },
        @{ Key='HKCU:\Software\Classes\Directory\Background\shell\Clintware_02_AdminPowerShell'; Arg='%V' }
    )
    foreach ($t in $targets) {
        if ($Enabled) {
            New-Item -Path "$($t.Key)\command" -Force | Out-Null
            Set-ItemProperty $t.Key '(default)' 'Clintware™ | Open Admin PowerShell Here'
            Set-ItemProperty $t.Key 'Icon' 'powershell.exe'
            Set-ItemProperty $t.Key 'Position' 'Top'
            $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$helper`" `"$($t.Arg)`""
            Set-ItemProperty "$($t.Key)\command" '(default)' $cmd
        } else {
            Remove-Item $t.Key -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
