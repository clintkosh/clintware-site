$script:ClassicKey = 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32'
function Test-ClintwareClassicMenuEnabled { Test-Path $script:ClassicKey }
function Set-ClintwareClassicMenu([bool]$Enabled) {
    if ($Enabled) {
        New-Item -Path $script:ClassicKey -Force | Out-Null
        Set-ItemProperty -Path $script:ClassicKey -Name '(default)' -Value ''
    } else {
        Remove-Item 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}' -Recurse -Force -ErrorAction SilentlyContinue
    }
}
