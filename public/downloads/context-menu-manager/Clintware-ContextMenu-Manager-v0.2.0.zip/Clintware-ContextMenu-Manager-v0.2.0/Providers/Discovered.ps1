function Get-ClintwareRegisteredShellVerbs {
    $roots = @(
        'HKCU:\Software\Classes\Directory\shell',
        'HKCU:\Software\Classes\Directory\Background\shell',
        'HKCU:\Software\Classes\*\shell'
    )
    foreach ($root in $roots) {
        if (Test-Path $root) {
            Get-ChildItem $root -ErrorAction SilentlyContinue | ForEach-Object {
                [pscustomobject]@{ Scope=$root; Key=$_.PSChildName }
            }
        }
    }
}
