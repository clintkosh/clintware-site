function Test-ClintwareTerminalAvailable { return [bool](Get-Command wt.exe -ErrorAction SilentlyContinue) }
