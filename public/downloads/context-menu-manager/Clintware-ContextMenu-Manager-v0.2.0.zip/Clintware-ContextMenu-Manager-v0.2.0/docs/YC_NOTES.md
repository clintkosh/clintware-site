# YC-facing product thesis — working notes

## Do not pitch the current utility as the whole company

Right-Click Menu Manager v0.2.0 is a credible product artifact and wedge, not yet a venture-scale claim by itself.

## Potential company-shaped thesis

**Clintware builds a developer workstation reliability layer that detects local configuration drift, repairs it safely, and proves how much developer time it gives back.**

The context-menu manager demonstrates the operating model: inspect the real machine, present explicit controls, snapshot before mutation, apply locally, and roll back cleanly. The same engine can extend to editor state, shell/toolchain configuration, resource pressure, startup degradation, and app-specific repair packs.

## Metrics needed before a YC claim becomes strong

- weekly active workstations
- successful repairs per workstation
- median time-to-recovery before vs. after Clintware
- repeat incident rate
- rollback rate / failed repair rate
- measured launch or interaction latency improvements where applicable
- number of repair packs actively used
- organic retention after 4 and 8 weeks

## Near-term validation

1. Ship the utility publicly and instrument only opt-in, privacy-preserving outcome metrics.
2. Recruit real Windows developer users with recurring workstation friction.
3. Identify the three problems that repeatedly cost the most time.
4. Build repair packs around those repeated problems instead of broadening by feature count.
5. Show measurable recovered time and repeated usage before framing the product as a workstation reliability platform.
