Set-StrictMode -Version Latest
$script:ProductName = 'Clintware™ Right-Click Menu Manager'
$script:Version = '0.2.0'
$script:InstallRoot = Join-Path $env:LOCALAPPDATA 'Clintware\ContextMenuManager'
$script:StateRoot = Join-Path $script:InstallRoot 'State'
$script:BackupRoot = Join-Path $script:InstallRoot 'Backups'

function Ensure-ClintwareFolders {
    New-Item -ItemType Directory -Force -Path $script:InstallRoot,$script:StateRoot,$script:BackupRoot | Out-Null
}

function Restart-ClintwareExplorer {
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
}

function Get-ClintwareSevenZip {
    @(
        "$env:ProgramFiles\7-Zip\7zG.exe",
        "${env:ProgramFiles(x86)}\7-Zip\7zG.exe"
    ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
}

function Get-ClintwarePwsh {
    $pwsh = Get-Command pwsh.exe -ErrorAction SilentlyContinue
    if ($pwsh) { return $pwsh.Source }
    $legacy = Get-Command powershell.exe -ErrorAction SilentlyContinue
    if ($legacy) { return $legacy.Source }
    throw 'No PowerShell executable was found.'
}

function Save-ClintwareSnapshot {
    Ensure-ClintwareFolders
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $file = Join-Path $script:BackupRoot "registry-$stamp.reg"
    $keys = @(
        'HKCU\Software\Classes\SystemFileAssociations',
        'HKCU\Software\Classes\Directory\shell',
        'HKCU\Software\Classes\Directory\Background\shell',
        'HKCU\Software\Classes\*\shell',
        'HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}'
    )
    $parts = @('Windows Registry Editor Version 5.00','')
    foreach ($key in $keys) {
        $tmp = Join-Path $env:TEMP ([guid]::NewGuid().ToString()+'.reg')
        & reg.exe export $key $tmp /y *> $null
        if (Test-Path $tmp) {
            $raw = Get-Content $tmp -Raw
            $raw = $raw -replace '^Windows Registry Editor Version 5\.00\s*',''
            $parts += $raw.Trim()
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }
    }
    Set-Content -LiteralPath $file -Value ($parts -join "`r`n`r`n") -Encoding Unicode
    Set-Content -LiteralPath (Join-Path $script:StateRoot 'last-backup.txt') -Value $file -Encoding UTF8
    return $file
}

function Restore-ClintwareLastSnapshot {
    $marker = Join-Path $script:StateRoot 'last-backup.txt'
    if (!(Test-Path $marker)) { throw 'No Clintware registry backup is available.' }
    $file = (Get-Content $marker -Raw).Trim()
    if (!(Test-Path $file)) { throw "Backup not found: $file" }
    & reg.exe import $file | Out-Null
    Restart-ClintwareExplorer
}
