param([Parameter(Mandatory=$true)][string]$Target)
$ErrorActionPreference='Stop'
$targetPath = [Environment]::ExpandEnvironmentVariables($Target.Trim('"'))
if (Test-Path -LiteralPath $targetPath -PathType Leaf) {
    $targetPath = Split-Path -LiteralPath $targetPath -Parent
}
if (!(Test-Path -LiteralPath $targetPath -PathType Container)) {
    throw "Folder not found: $targetPath"
}
$pwsh = (Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source
if (-not $pwsh) { $pwsh = (Get-Command powershell.exe -ErrorAction Stop).Source }
$escaped = $targetPath.Replace("'","''")
Start-Process $pwsh -Verb RunAs -ArgumentList @('-NoExit','-Command',"Set-Location -LiteralPath '$escaped'")
