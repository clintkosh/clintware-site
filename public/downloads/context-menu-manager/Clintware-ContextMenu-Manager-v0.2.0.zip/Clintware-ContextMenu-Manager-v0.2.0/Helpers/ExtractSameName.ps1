param([Parameter(Mandatory=$true)][string]$Archive)
$ErrorActionPreference='Stop'
$archivePath = [Environment]::ExpandEnvironmentVariables($Archive.Trim('"'))
if (!(Test-Path -LiteralPath $archivePath -PathType Leaf)) { throw "Archive not found: $archivePath" }
$seven = @("$env:ProgramFiles\7-Zip\7zG.exe","${env:ProgramFiles(x86)}\7-Zip\7zG.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $seven) { throw '7-Zip was not found.' }
$item = Get-Item -LiteralPath $archivePath
$outFolder = Join-Path $item.DirectoryName $item.BaseName
New-Item -ItemType Directory -Force -Path $outFolder | Out-Null
& $seven x $archivePath "-o$outFolder" -y
if ($LASTEXITCODE -gt 1) { throw "7-Zip returned exit code $LASTEXITCODE" }
