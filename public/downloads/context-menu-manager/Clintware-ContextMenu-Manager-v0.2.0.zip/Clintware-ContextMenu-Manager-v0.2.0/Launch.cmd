@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Clintware.ContextMenuManager.ps1"
