# Clintware™ Right-Click Menu Manager

Local-first Windows 11 context-menu manager. Version 0.2.0.

## What changed in v0.2.0

The fast path requested during live Windows 11 testing is now part of the main installer and the app itself:

- **Clintware™ | 7-Zip Extract to Same-Name Folder**
- **Clintware™ | Open Admin PowerShell Here**
- Ordered `Clintware_01` / `Clintware_02` shell keys keep the branded quick actions grouped on archive right-clicks.
- Admin PowerShell works from a file, a folder, or blank folder background and opens in the relevant directory.
- Classic/full Windows 11 context menu is enabled by default during normal installation so traditional shell verbs are directly visible. It remains a toggle in the app.
- The installer snapshots relevant registry state before applying changes.
- Undo Last Apply imports the most recent Clintware snapshot.

## Install

Right-click `Install.ps1` and run with PowerShell, or from PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Install.ps1 -Launch
```

The installer self-elevates once. Runtime files live at `%LOCALAPPDATA%\Clintware\ContextMenuManager`.

### Installer switches

- `-KeepCompactMenu` keeps the Windows 11 compact menu instead of making the classic/full menu default.
- `-NoQuickActions` installs the manager without enabling the two Clintware quick actions.
- `-Launch` opens the toggle UI when installation completes.

## Safety

All Clintware shell verbs are created under the current user's `HKCU\Software\Classes` tree. Unknown third-party COM shell extensions are not removed. Registry state is backed up before Apply. The app favors reversible changes rather than destructive shell-extension cleanup.
