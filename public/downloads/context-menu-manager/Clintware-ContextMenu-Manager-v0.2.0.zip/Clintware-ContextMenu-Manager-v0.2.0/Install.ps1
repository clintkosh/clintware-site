param(
    [switch]$KeepCompactMenu,
    [switch]$NoQuickActions,
    [switch]$Launch
)
$ErrorActionPreference='Stop'

# One-time installer self-elevates so the same block works from an admin or non-admin window.
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    if($KeepCompactMenu){$args+='-KeepCompactMenu'}
    if($NoQuickActions){$args+='-NoQuickActions'}
    if($Launch){$args+='-Launch'}
    Start-Process powershell.exe -Verb RunAs -ArgumentList $args
    exit
}

$source=Split-Path -Parent $MyInvocation.MyCommand.Path
$dest=Join-Path $env:LOCALAPPDATA 'Clintware\ContextMenuManager'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Get-ChildItem $source -Force | Where-Object Name -notin @('State','Backups') | Copy-Item -Destination $dest -Recurse -Force

. (Join-Path $dest 'Core\Engine.ps1')
. (Join-Path $dest 'Providers\Windows.ps1')
. (Join-Path $dest 'Providers\SevenZip.ps1')
. (Join-Path $dest 'Providers\PowerShell.ps1')
Ensure-ClintwareFolders
$backup=Save-ClintwareSnapshot

if (-not $KeepCompactMenu) { Set-ClintwareClassicMenu $true }
if (-not $NoQuickActions) {
    if (Get-ClintwareSevenZip) { Set-ClintwareExtractSameName $true }
    Set-ClintwareAdminHere $true
}

$shortcutDir=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Clintware'
New-Item -ItemType Directory -Force -Path $shortcutDir | Out-Null
$ws=New-Object -ComObject WScript.Shell
$shortcut=$ws.CreateShortcut((Join-Path $shortcutDir 'Right-Click Menu Manager.lnk'))
$shortcut.TargetPath='powershell.exe'
$shortcut.Arguments="-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $dest 'Clintware.ContextMenuManager.ps1')`""
$shortcut.WorkingDirectory=$dest
$shortcut.IconLocation='powershell.exe,0'
$shortcut.Save()
Restart-ClintwareExplorer

Write-Host ''
Write-Host 'Clintware™ Right-Click Menu Manager v0.2.0 installed.' -ForegroundColor Cyan
Write-Host "Install: $dest"
Write-Host "Backup:  $backup"
Write-Host 'Enabled by default:'
if(-not $KeepCompactMenu){Write-Host '  - Classic/full Windows 11 context menu'}
if(-not $NoQuickActions){
    if(Get-ClintwareSevenZip){Write-Host '  - Clintware™ | 7-Zip Extract to Same-Name Folder'}
    Write-Host '  - Clintware™ | Open Admin PowerShell Here'
}
Write-Host 'Use the Start menu app to toggle these settings later.'
if($Launch){ & (Join-Path $dest 'Clintware.ContextMenuManager.ps1') }
