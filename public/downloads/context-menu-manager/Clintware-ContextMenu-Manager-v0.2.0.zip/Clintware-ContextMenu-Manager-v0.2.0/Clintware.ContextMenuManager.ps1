$ErrorActionPreference='Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $root 'Core\Engine.ps1')
. (Join-Path $root 'Providers\Windows.ps1')
. (Join-Path $root 'Providers\SevenZip.ps1')
. (Join-Path $root 'Providers\PowerShell.ps1')
. (Join-Path $root 'Providers\Terminal.ps1')
. (Join-Path $root 'Providers\Discovered.ps1')
Ensure-ClintwareFolders

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Clintware™ Right-Click Menu Manager v0.2.0'
$form.Size = New-Object System.Drawing.Size(760,540)
$form.StartPosition='CenterScreen'
$form.BackColor=[System.Drawing.Color]::FromArgb(12,18,24)
$form.ForeColor=[System.Drawing.Color]::Gainsboro
$form.Font=New-Object System.Drawing.Font('Segoe UI',10)

$title = New-Object System.Windows.Forms.Label
$title.Text='CLINTWARE™  |  RIGHT-CLICK MENU MANAGER'
$title.Location=New-Object System.Drawing.Point(26,22)
$title.AutoSize=$true
$title.Font=New-Object System.Drawing.Font('Consolas',14,[System.Drawing.FontStyle]::Bold)
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text='Local-first Explorer controls. Previewable, reversible, and per-user where practical.'
$sub.Location=New-Object System.Drawing.Point(28,54)
$sub.AutoSize=$true
$sub.ForeColor=[System.Drawing.Color]::Silver
$form.Controls.Add($sub)

$classic = New-Object System.Windows.Forms.CheckBox
$classic.Text='Use classic/full Windows 11 context menu as default'
$classic.Location=New-Object System.Drawing.Point(30,100)
$classic.Size=New-Object System.Drawing.Size(650,28)
$classic.Checked=(Test-ClintwareClassicMenuEnabled)
$form.Controls.Add($classic)

$zip = New-Object System.Windows.Forms.CheckBox
$zip.Text='Clintware™ | 7-Zip Extract to Same-Name Folder'
$zip.Location=New-Object System.Drawing.Point(30,140)
$zip.Size=New-Object System.Drawing.Size(650,28)
$zip.Checked=(Test-ClintwareExtractSameNameEnabled)
$zip.Enabled=[bool](Get-ClintwareSevenZip)
$form.Controls.Add($zip)

$admin = New-Object System.Windows.Forms.CheckBox
$admin.Text='Clintware™ | Open Admin PowerShell Here'
$admin.Location=New-Object System.Drawing.Point(30,180)
$admin.Size=New-Object System.Drawing.Size(650,28)
$admin.Checked=(Test-ClintwareAdminHereEnabled)
$form.Controls.Add($admin)

$note = New-Object System.Windows.Forms.Label
$note.Text='Archive right-clicks use ordered Clintware_01 / Clintware_02 verbs so the two Clintware actions stay grouped. Admin PowerShell also works on files, folders, and folder backgrounds.'
$note.Location=New-Object System.Drawing.Point(30,220)
$note.Size=New-Object System.Drawing.Size(680,55)
$note.ForeColor=[System.Drawing.Color]::DarkGray
$form.Controls.Add($note)

$preview = New-Object System.Windows.Forms.TextBox
$preview.Location=New-Object System.Drawing.Point(30,286)
$preview.Size=New-Object System.Drawing.Size(680,105)
$preview.Multiline=$true
$preview.ReadOnly=$true
$preview.BackColor=[System.Drawing.Color]::FromArgb(8,12,17)
$preview.ForeColor=[System.Drawing.Color]::LightGray
$preview.Font=New-Object System.Drawing.Font('Consolas',9)
$form.Controls.Add($preview)

function Refresh-Preview {
    $z = if ($zip.Enabled) { if($zip.Checked){'ON'}else{'OFF'} } else {'UNAVAILABLE (7-Zip not detected)'}
    $preview.Text = "PENDING STATE`r`nClassic/full menu: $($classic.Checked)`r`n7-Zip same-name quick action: $z`r`nAdmin PowerShell Here: $($admin.Checked)"
}
$classic.Add_CheckedChanged({Refresh-Preview})
$zip.Add_CheckedChanged({Refresh-Preview})
$admin.Add_CheckedChanged({Refresh-Preview})
Refresh-Preview

$apply = New-Object System.Windows.Forms.Button
$apply.Text='Apply'
$apply.Location=New-Object System.Drawing.Point(30,414)
$apply.Size=New-Object System.Drawing.Size(115,36)
$form.Controls.Add($apply)

$undo = New-Object System.Windows.Forms.Button
$undo.Text='Undo Last Apply'
$undo.Location=New-Object System.Drawing.Point(158,414)
$undo.Size=New-Object System.Drawing.Size(145,36)
$form.Controls.Add($undo)

$restart = New-Object System.Windows.Forms.Button
$restart.Text='Restart Explorer'
$restart.Location=New-Object System.Drawing.Point(316,414)
$restart.Size=New-Object System.Drawing.Size(145,36)
$form.Controls.Add($restart)

$status = New-Object System.Windows.Forms.Label
$status.Text='Ready'
$status.Location=New-Object System.Drawing.Point(30,468)
$status.Size=New-Object System.Drawing.Size(680,25)
$status.ForeColor=[System.Drawing.Color]::LightGreen
$form.Controls.Add($status)

$apply.Add_Click({
    try {
        $status.Text='Backing up registry and applying changes...'
        [System.Windows.Forms.Application]::DoEvents()
        $backup=Save-ClintwareSnapshot
        Set-ClintwareClassicMenu $classic.Checked
        if ($zip.Enabled) { Set-ClintwareExtractSameName $zip.Checked }
        Set-ClintwareAdminHere $admin.Checked
        Restart-ClintwareExplorer
        $status.Text="Applied. Backup: $backup"
    } catch { $status.Text="ERROR: $($_.Exception.Message)" }
})
$undo.Add_Click({
    try { Restore-ClintwareLastSnapshot; $status.Text='Last registry snapshot restored.' }
    catch { $status.Text="ERROR: $($_.Exception.Message)" }
})
$restart.Add_Click({ Restart-ClintwareExplorer; $status.Text='Explorer restarted.' })

[void]$form.ShowDialog()
