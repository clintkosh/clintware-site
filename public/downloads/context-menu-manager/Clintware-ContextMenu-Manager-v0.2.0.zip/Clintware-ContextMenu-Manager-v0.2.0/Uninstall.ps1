$ErrorActionPreference='Stop'
$dest=Join-Path $env:LOCALAPPDATA 'Clintware\ContextMenuManager'
if(Test-Path (Join-Path $dest 'Core\Engine.ps1')){
 . (Join-Path $dest 'Core\Engine.ps1')
 . (Join-Path $dest 'Providers\Windows.ps1')
 . (Join-Path $dest 'Providers\SevenZip.ps1')
 . (Join-Path $dest 'Providers\PowerShell.ps1')
 Set-ClintwareExtractSameName $false
 Set-ClintwareAdminHere $false
 Set-ClintwareClassicMenu $false
 Restart-ClintwareExplorer
}
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Clintware\Right-Click Menu Manager.lnk') -Force -ErrorAction SilentlyContinue
Write-Host 'Clintware™ context-menu integrations removed. Backups were left in LocalAppData.'
